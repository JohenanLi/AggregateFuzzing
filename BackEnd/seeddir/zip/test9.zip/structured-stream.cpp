/* -*- Mode: C++; tab-width: 4; indent-tabs-mode: t; c-basic-offset: 4 -*- */

#include <cassert>

#include <boost/scoped_ptr.hpp>

#include <librevenge-stream/librevenge-stream.h>

int main(int argc, char *argv[])
{
  char *file = 0;

  if (argc != 2)
    return 1;

  file = argv[1];
  if (!file)
    return 1;

  librevenge::RVNGFileStream stream(file);
}

/* vim:set shiftwidth=2 softtabstop=2 expandtab: */
